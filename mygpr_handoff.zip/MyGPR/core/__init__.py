"""Core application modules."""
